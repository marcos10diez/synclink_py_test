import setuptools

setuptools.setup(
    name="mgapi",
    version="1.4.2",
    author="Microgate Systems, Ltd",
    author_email="support@microgate.com",
    description="Wrapper for Microgate Serial API",
    url="www.microgate.com",
    license="MIT",
    py_modules=["mgapi"],
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: Windows",
    ],
)